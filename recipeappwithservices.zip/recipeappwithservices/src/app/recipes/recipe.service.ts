import { Recipe } from './recipe.model';
import { Ingredient } from '../shared/ingredient.model';
import { EventEmitter, Injectable } from '@angular/core';
import { ShoppingListService } from '../shopping-list/shoppinglist.service';
@Injectable()
export class RecipeService{
    private recipes:Recipe[]=[
        new Recipe('Fat Burger','Too much calried food','https://images.unsplash.com/photo-1550949987-33f716ccc232?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=708&q=80',[
            new Ingredient('meat',1),
            new Ingredient('tomatoes',3)
        ]),
        new Recipe('Chicken curry','Too spicy food','https://images.unsplash.com/photo-1564834744159-ff0ea41ba4b9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80',[
            new Ingredient('chicken',1),
            new Ingredient('chilis',3)
        ])
    ]
    recipeSelected=new EventEmitter<Recipe>();
    constructor(private shoppingListService:ShoppingListService){
    }
    getRecipes()
    {
        return this.recipes.slice();
    }
    addIngredientsToShoppingList(ingredients:Ingredient[])
    {
        this.shoppingListService.addIngredients(ingredients);
    }
}