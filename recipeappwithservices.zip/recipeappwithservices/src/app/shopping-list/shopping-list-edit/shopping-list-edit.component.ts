import { Component, OnInit } from '@angular/core';
import { ShoppingListService } from '../shoppinglist.service';
import { Ingredient } from 'src/app/shared/ingredient.model';

@Component({
  selector: 'app-shopping-list-edit',
  templateUrl: './shopping-list-edit.component.html',
  styleUrls: ['./shopping-list-edit.component.css']
})
export class ShoppingListEditComponent implements OnInit {

  constructor(private shoppingListService:ShoppingListService) { }

  ngOnInit(): void {
  }
  onAddIngredient(name:string,amount:string){
    this.shoppingListService.addIngredient(new Ingredient(name,+amount));
  }

}
