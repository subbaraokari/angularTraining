import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../accounts/account.service';

@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html',
  styleUrls: ['./new-account.component.css']
})
export class NewAccountComponent implements OnInit {

  constructor(private accountService:AccountsService) { }

  ngOnInit(): void {
    this.accountService.statusChanged.subscribe((status:string)=>{
      alert(status);
    })
  }
  onAdd(name:string,status:string){
    this.accountService.addAccount(name,status);
  }

}
