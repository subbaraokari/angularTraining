export class LoggingService{
    changeStatus(status:string){
        console.log('The status is changed New status is '+status)
    }
}