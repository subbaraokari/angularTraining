import { LoggingService } from '../logging.service';
import { Injectable, EventEmitter } from '@angular/core';
@Injectable()
export class AccountsService
{
    private accounts:{name:string,status:string}[]=[
        {
            name:'Master Account',
            status:'active'
        },
        {
            name:'Test account',
            status:'inactive'
        },
        {
            name:'hideen acoount',
            status:'hidden'
        }
    ];
    statusChanged=new EventEmitter<string>();
    constructor(private loggingService:LoggingService){

    }
    getAccounts()
    {
        return this.accounts;
    }
    updateStatus(id:number,status:string){
        this.accounts[id].status=status;
        this.loggingService.changeStatus(status);
    }
    addAccount(name:string,status:string)
    {
        console.log(name,status);
        this.accounts.push({name:name,status:status});
    }


}