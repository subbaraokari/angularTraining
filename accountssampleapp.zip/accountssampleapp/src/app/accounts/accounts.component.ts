import { Component, OnInit, Input } from '@angular/core';
import { AccountsService } from './account.service';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  @Input() account:{name:string,status:string};
  @Input() id:number;
  constructor(private accountService:AccountsService) { }

  ngOnInit(): void {
  }
  onChangeStatus(status:string){
    this.accountService.updateStatus(this.id,status);
    this.accountService.statusChanged.emit(status);
  }
  

}
