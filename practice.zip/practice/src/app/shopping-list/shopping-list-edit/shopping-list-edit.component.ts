import { Component, OnInit, ElementRef, ViewChild, EventEmitter, Output } from '@angular/core';
import { Ingredient } from '../ingredient.model';

@Component({
  selector: 'app-shopping-list-edit',
  templateUrl: './shopping-list-edit.component.html',
  styleUrls: ['./shopping-list-edit.component.css']
})
export class ShoppingListEditComponent implements OnInit {
  @ViewChild('nameInputText') nameInputRef:ElementRef;
  @ViewChild('amountInputText') amountInputRef:ElementRef;
  @Output() ingredientAdded=new EventEmitter<Ingredient>();
  constructor() { }

  ngOnInit(): void {
  }
  onAddIngredient(){
    console.log(this.nameInputRef.nativeElement.value);
    this.ingredientAdded.emit(new Ingredient(this.nameInputRef.nativeElement.value,+this.amountInputRef.nativeElement.value));
  }

}
