import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes:Recipe[];
  @Output() recipeWasSelected=new EventEmitter<Recipe>();

  constructor() { }

  ngOnInit(): void {
    this.recipes=[
      new Recipe('Pizza','This is tasty','https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=414&q=80'),
      new Recipe('Burger','Good calorie food','https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=602&q=80')
    ];
  }
  onRecipeWasSelected(recipe:Recipe)
  {
    this.recipeWasSelected.emit(recipe);
  }

}
