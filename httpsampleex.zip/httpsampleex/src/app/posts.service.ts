import { Injectable } from '@angular/core';
import { Post } from './post.model';
import { HttpClient } from '@angular/common/http';
import { Subject, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators'

@Injectable()
export class PostService
{   
    error=new Subject<string>();
    constructor(private http:HttpClient){

    }
    createAndStorePost(title:string,content:string){
        const postData:Post={title:title,content:content};
        this.http.post("https://postsapp-94239.firebaseio.com/posts.json",postData).subscribe((responseData)=>{
            console.log(responseData);
        },(resError)=>{
            this.error.next(resError.message);
        })
    }
    fetchPosts(){
       return this.http.get("https://postsapp-94239.firebaseio.com/posts.json").pipe(map((postData)=>{
            const postArray=[];
            for(let key in postData){
                postArray.push({...postData[key],id:key});
            }
            return postArray;
        }),
        catchError(errMsg=>{
            return throwError(errMsg);
        }));
    }
    
}