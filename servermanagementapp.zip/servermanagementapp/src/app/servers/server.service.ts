export class ServerService{
    private servers:{id:number,name:string,status:string}[]=[
        {
            id:1,
            name:'Production server',
            status:'online'
        },
        {
            id:2,
            name:'Dev Server',
            status:'offline'
        },
        {
            id:3,
            name:'stage server',
            status:'offline'
        }
    ];
    getServers()
    {
        return this.servers;
    }
    getServer(id:number){
        return this.servers.find((server)=>{
            return server.id===id;
        });       
    }
    updateServer(id:number,serverInfo:{name:string,status:string}){
        const server=this.servers.find(server=>server.id===id);
        if(server){
            server.name=serverInfo.name;
            server.status=serverInfo.status;
        }
    }

}